package com.example.admin.signup;

import android.widget.Button;

/**
 * Created by Admin on 01-02-2020.
 */
public class Constants {
    private static Constants ourInstance = new Constants();

    public static Constants getInstance() {
        return ourInstance;
    }

    private Constants() {
         Button A11;
    }
}
